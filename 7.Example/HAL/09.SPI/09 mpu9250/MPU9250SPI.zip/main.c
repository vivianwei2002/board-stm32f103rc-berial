/***************************************************************/
//Funcation: MPU-9250 SPI device
//chip��stm32f103c8t6
//development environment��keil5.17
//edit time:2016��7��28��16:42:44
/***************************************************************/
#include "Global.h"

uint16 Classification(void);//����
extern double exp(double __x);

s32 V=0,Feng=0,S=0;
uint16 Result;

uint16 send_data[9]={0,0,0,0,0,0,0,0,0};
uint16 Sample[9];
double Output[6];

int Number_Sample=200;
int16 ACCEL_X[200];
int16 ACCEL_Y[200];
int16 ACCEL_Z[200];
int16 GYRO_X[200];
int16 GYRO_Y[200];
int16 GYRO_Z[200];
int16 MAG_X[200];
int16 MAG_Y[200];
int16 MAG_Z[200];

int16 GetFeng(int16 accel[]);
int16 Getsig(int16 accel[]);
int16 GetSMA(int16 accel_X[],int16 accel_Y[],int16 accel_Z[]);

int main()
{
	int i = 0;
	int j = 0;
	send_data[6] = 82;//��ʼ�������ʾ
	
	SystemInit();
	WiFi_Init();//WiFi�������ų�ʼ��
	delay_init();
	uart_init();
	spi_Init();
	Init_MPU9250();	
	delay_ms(10);
	
	//WiFi_Reset();//WiFi����
	
	while(1)
	{
		READ_MPU9250_ACCEL();
		READ_MPU9250_GYRO();
		READ_MPU9250_MAG();
		
		send_data[0]=mpu_value.Accel[0];
		send_data[1]=mpu_value.Accel[1];
		send_data[2]=mpu_value.Accel[2];
	  send_data[3]= mpu_value.Gyro[0];
	  send_data[4]= mpu_value.Gyro[1];
		send_data[5]= mpu_value.Gyro[2];
	  send_data[6]= mpu_value.Mag[0];
	  send_data[7]= mpu_value.Mag[1];
		send_data[8]= mpu_value.Mag[2];
		Data_send(send_data);
		delay_ms(10);//���ڲ�������

	}
}

int16 GetFeng(int16 accel[])
{
  int i;
	int16 MAX=0,MIN=0,FENG=0;
	MAX=accel[0];
	MIN=accel[0];
	for(i=1;i < Number_Sample;i++)
	{
		if(accel[i] > MAX)
		{ MAX=accel[i];}
    if(accel[i] < MIN)
		{	MIN=accel[i];}
	}
	FENG = MAX - MIN;
	return FENG;
}


int16 Getsig(int16 accel[])//����
{
	int i;
	int32 sig=0,S=0,M=0;
	for(i=1;i < Number_Sample;i++)
	{
		S=S+accel[i];
	}
	S=S/Number_Sample;
	for(i=1;i < Number_Sample;i++)
	{
		M=M+(accel[i]-S)*(accel[i]-S)/Number_Sample;
	}
	sig = M/10;
	return sig;
}

int16 GetSMA(int16 accel_X[],int16 accel_Y[],int16 accel_Z[])//��ֵ���
{
	int i;
	int32 SMA=0,S=0;
	for(i=1;i < Number_Sample;i++)
	{
		S=S+abs(accel_X[i])+abs(accel_Y[i])+abs(accel_Z[i]);
	}
	SMA=S/Number_Sample;

	return SMA;
}

uint16 Classification(void) 
{
	int i,j;
  uint16 result;
//	double A,S;
//	double Inputweight[10][6]=
//	{   
//   {-0.8163,    0.1016,   -0.1901,   -0.9304,    0.6338,    0.5209},
//   {-0.1958,    0.7418,   -0.6529,   -0.4143,   -0.6211,    0.7107},
//   {-0.4096,   -0.9155,    0.1504,    0.6029,   -0.7526,   -0.2343},
//   {-0.3870,    0.8094,    0.2124,   -0.3070,    0.6420,   -0.8307},
//   {-0.7889,   -0.7381,   -0.5711,   -0.8334,    0.2758,    0.4677},
//   { 0.1877,    0.6675,    0.0399,    0.0222,   -0.9678,   -0.3360},
//   {-0.4345,    0.6009,    0.9784,   -0.2663,    0.7919,    0.6795},
//   {-0.6896,    0.8358,   -0.0202,    0.4790,    0.0308,   -0.2566},
//   {-0.9987,   -0.7254,    0.3897,    0.0495,    0.0890,    0.6564},
//   {-0.4328,    0.0095,   -0.1772,    0.6090,    0.2129,   -0.6470},
//	};
//	double Bi[10]=
//		{ 
//    0.1295,
//    0.8799,
//    0.0441,
//    0.6867,
//    0.7338,
//    0.4372,
//    0.3798,
//    0.9797,
//    0.3990,
//    0.4402,
//		};
//	double tempH[10];
//	double temp_H[10];
//	double H[10];
//	double  Outputweight[10][3]=
//	{ 
//	 {-0.0073,   -0.0268,    0.0341},
//   { 0.0000,   -0.0000,    0.0000},
//   { 0.0000,    0.5856,   -0.5856},
//   { 0.0279,   -0.1513,    0.1233},
//   {-0.0000,    0.0000,   -0.0000},
//   { 0.0228,   -0.4290,    0.4063},
//   {-1.0013,    0.9742,   -0.9729},
//   {-0.0190,   -1.5538,    1.5728},
//   { 1.9548,   -1.5708,   -0.3840},
//   {-0.0003,   -0.2424,    0.2427},	
//	};

//  A=0;	S=0;
//	for(i=0;i<10;i++)
//	{
//		for(j=0;j<6;j++)
//		{
//			A=Inputweight[i][j]*Sample[j];
//			S=A+S;
//		}
//		temp_H[i] = S;
//	 }
//	  for(i=0;i<10;i++) 
//			{
//				tempH[i] = temp_H[i] + Bi[i];
//			  H[i] = 1./(1+exp(-tempH[i]));
//			}
//  A=0;	 S=0;
//		for(i=0;i<3;i++)
//	 {
//		for(j=0;j<10;j++)
//		{
//			A=H[j] * Outputweight[j][i];
//			S=A+S;
//		}
//		Output[i] = S;
//	 }
//	 
//		if (Output[0]>Output[1]&&Output[0]>Output[2])
//		{			result=82;		}
//				if (Output[1]>Output[0]&&Output[1]>Output[2])
//		{			result=83;		}
//				if (Output[2]>Output[1]&&Output[2]>Output[0])
//		{			result=84;		}	
		if (Sample[0]<45)
		{			result=82;		}
		if (Sample[0]>55 && Sample[0]<140)
		{			result=83;		}
		if (Sample[0]>140)
		{			result=84;		}
		return result;
}



