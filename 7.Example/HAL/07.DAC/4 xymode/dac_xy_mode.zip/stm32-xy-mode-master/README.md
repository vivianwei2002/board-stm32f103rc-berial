# stm32-xy-mode

STM32 DAC example: drawing on oscilloscope in XY-mode.

Requires STM32F405 or STM32F415 with two DACs. The output is on pins PA4 and PA5.
